package com.example.quran_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
